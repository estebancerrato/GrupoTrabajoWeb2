var doc = new jsPDF('landscape');
doc.text(20, 20, 'Hello landscape world!');